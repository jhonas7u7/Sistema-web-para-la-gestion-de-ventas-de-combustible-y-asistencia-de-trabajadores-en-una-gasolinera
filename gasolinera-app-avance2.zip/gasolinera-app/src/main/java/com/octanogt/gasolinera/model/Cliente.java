package com.octanogt.gasolinera.model;

/** Cliente registrado en el sistema. */
public class Cliente {

    private Long id;
    private String nombre;
    private String documento;
    private String telefono;
    private String correo;
    private String estado; // Activo, Inactivo

    public Cliente() { }

    public Cliente(Long id, String nombre, String documento, String telefono, String correo, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.documento = documento;
        this.telefono = telefono;
        this.correo = correo;
        this.estado = estado;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
